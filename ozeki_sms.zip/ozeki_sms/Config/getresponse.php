<?php
 #http://127.0.0.1:82/sms/getresponse.php?sender=$originator&receiver=$recipient&msgdata=$messagedata
 #                         &recvtime=$receivedtime&msgid=$messageid
 
 $sender = $_REQUEST['sender'];
 $receiver = $_REQUEST['receiver'];
 $msgdata = $_REQUEST['msgdata'];

 echo "{GSMSMS}{}{".$sender."}{".$receiver."}{Thank you for your SMS! WWW.OZEKI.HU}\n".
      "{GSMSMS}{}{+36205552245}{".$receiver."}{".$sender." ".$msgdata."}\n";

?>