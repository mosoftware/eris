I-Warez 2015
------------

How to activate:
- Stop the Ozeki Service
- Copy the files in the activation folder to the Ozeki installation folder (C:\Program Files (x86)\Ozeki\OzekiNG - SMS Gateway)
- Start the Ozeki Service
- You should be ready